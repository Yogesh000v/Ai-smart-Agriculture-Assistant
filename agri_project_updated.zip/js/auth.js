/**
 * ============================================================================
 * AI Smart Agriculture Assistant - Authentication & User Profile Controller
 * Handles user signup, login, session token persistence, and header widgets.
 * Full Offline & Online Support with Local Storage Account Database.
 * ============================================================================
 */

const LocalUsers = {
  KEY: 'agri_registered_users',

  getAll() {
    try {
      const data = JSON.parse(localStorage.getItem(this.KEY));
      if (Array.isArray(data) && data.length > 0) return data;
    } catch (e) {}

    // Default seeded demo user
    const defaults = [{
      id: 1,
      full_name: "Dr. Ramesh Patel",
      email: "admin@agrotech.com",
      password: "AgroPass123!",
      role: "Chief Agronomist & Farm Manager",
      farm_name: "GreenHorizon Smart Agro-Tech Farm",
      created_at: new Date().toISOString()
    }];
    this.saveAll(defaults);
    return defaults;
  },

  saveAll(users) {
    localStorage.setItem(this.KEY, JSON.stringify(users));
  },

  register(userData) {
    const users = this.getAll();
    const cleanEmail = userData.email.toLowerCase().trim();

    if (users.some(u => u.email.toLowerCase().trim() === cleanEmail)) {
      return { ok: false, error: "This email is already registered. Please sign in instead." };
    }

    const newUser = {
      id: Date.now(),
      full_name: userData.full_name.trim(),
      email: cleanEmail,
      password: userData.password,
      role: userData.role || "Farmer / Farm Owner",
      farm_name: userData.farm_name ? userData.farm_name.trim() : "My Agricultural Farm",
      phone: userData.phone ? userData.phone.trim() : "",
      created_at: new Date().toISOString()
    };

    users.push(newUser);
    this.saveAll(users);

    const { password: _, ...safeUser } = newUser;
    return { ok: true, user: safeUser };
  },

  login(email, password) {
    const users = this.getAll();
    const cleanEmail = email.toLowerCase().trim();
    const user = users.find(u => u.email.toLowerCase().trim() === cleanEmail);

    if (!user) {
      return { ok: false, error: "No account found with this email. Please register first." };
    }

    if (user.password !== password) {
      return { ok: false, error: "Incorrect password. Please try again." };
    }

    const { password: _, ...safeUser } = user;
    return { ok: true, user: safeUser };
  }
};

const Auth = {
  currentUser: null,
  token: null,

  init() {
    this.loadSession();
    this.bindModalEvents();
    this.bindForms();
  },

  loadSession() {
    const savedUser = localStorage.getItem('agri_auth_user');
    const savedToken = localStorage.getItem('agri_auth_token');

    if (savedUser && savedToken) {
      try {
        this.currentUser = JSON.parse(savedUser);
        this.token = savedToken;
        this.updateHeaderProfile();
      } catch (e) {
        this.clearSession();
      }
    } else {
      this.updateHeaderProfile();
    }
  },

  saveSession(user, token) {
    this.currentUser = user;
    this.token = token;
    localStorage.setItem('agri_auth_user', JSON.stringify(user));
    localStorage.setItem('agri_auth_token', token);
    this.updateHeaderProfile();

    if (window.Market && typeof window.Market.render === 'function') {
      window.Market.render();
    }
  },

  clearSession() {
    this.currentUser = null;
    this.token = null;
    localStorage.removeItem('agri_auth_user');
    localStorage.removeItem('agri_auth_token');
    this.updateHeaderProfile();

    if (window.Market && typeof window.Market.render === 'function') {
      window.Market.render();
    }
  },

  bindModalEvents() {
    const modal = document.getElementById('authModal');
    const openBtn = document.getElementById('openAuthModalBtn');
    const closeBtn = document.getElementById('closeAuthModalBtn');
    const switchLogin = document.getElementById('switchLoginBtn');
    const switchRegister = document.getElementById('switchRegisterBtn');
    const quickDemoBtn = document.getElementById('quickDemoLoginBtn');

    if (openBtn) {
      openBtn.addEventListener('click', () => this.showModal('login'));
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => this.hideModal());
      modal.addEventListener('click', (e) => {
        if (e.target === modal) this.hideModal();
      });
    }

    if (switchLogin && switchRegister) {
      switchLogin.addEventListener('click', () => this.toggleTab('login'));
      switchRegister.addEventListener('click', () => this.toggleTab('register'));
    }

    if (quickDemoBtn) {
      quickDemoBtn.addEventListener('click', () => {
        const emailEl = document.getElementById('loginEmail');
        const passEl = document.getElementById('loginPassword');
        if (emailEl) emailEl.value = 'admin@agrotech.com';
        if (passEl) passEl.value = 'AgroPass123!';
        if (window.App && App.toast) {
          App.toast("Demo credentials populated. Click 'Sign In'!", "info");
        }
      });
    }
  },

  showModal(tab = 'login') {
    const modal = document.getElementById('authModal');
    if (modal) {
      modal.style.display = 'flex';
      this.toggleTab(tab);
    }
  },

  hideModal() {
    const modal = document.getElementById('authModal');
    if (modal) modal.style.display = 'none';
  },

  toggleTab(tab) {
    const loginForm = document.getElementById('loginForm');
    const regForm = document.getElementById('registerForm');
    const switchLogin = document.getElementById('switchLoginBtn');
    const switchRegister = document.getElementById('switchRegisterBtn');
    const title = document.getElementById('authModalTitle');

    if (tab === 'login') {
      if (loginForm) loginForm.style.display = 'block';
      if (regForm) regForm.style.display = 'none';
      if (switchLogin) switchLogin.classList.add('active');
      if (switchRegister) switchRegister.classList.remove('active');
      if (title) title.textContent = 'Sign In to Smart Agro-Tech';
    } else {
      if (loginForm) loginForm.style.display = 'none';
      if (regForm) regForm.style.display = 'block';
      if (switchLogin) switchLogin.classList.remove('active');
      if (switchRegister) switchRegister.classList.add('active');
      if (title) title.textContent = 'Create Agricultural Account';
    }
  },

  bindForms() {
    // 1. Login Form Submit
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail')?.value.trim();
        const password = document.getElementById('loginPassword')?.value;
        const submitBtn = document.getElementById('submitLoginBtn');

        if (!email || !password) {
          if (window.App?.toast) App.toast("Please fill in email and password.", "error");
          return;
        }

        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Verifying...';
        }

        try {
          if (window.App && App.isBackendLive) {
            const res = await fetch(`${App.apiBase}/api/auth/login`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email, password })
            });

            if (res.ok) {
              const data = await res.json();
              this.saveSession(data.user, data.token);
              this.hideModal();
              if (window.App?.toast) App.toast(data.message || `Welcome back, ${data.user.full_name}!`, "success");
              return;
            } else {
              const err = await res.json();
              if (window.App?.toast) App.toast(err.detail || "Authentication failed.", "error");
              return;
            }
          }
        } catch (err) {
          // Backend offline -> proceed to local check
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Sign In';
          }
        }

        // Local Offline Authentication Check
        const result = LocalUsers.login(email, password);
        if (result.ok) {
          this.saveSession(result.user, 'local-token-' + Date.now());
          this.hideModal();
          if (window.App?.toast) {
            App.toast(`Welcome back, ${result.user.full_name}!`, "success");
          }
        } else {
          if (window.App?.toast) {
            App.toast(result.error, "error");
          }
        }
      });
    }

    // 2. Register Form Submit
    const regForm = document.getElementById('registerForm');
    if (regForm) {
      regForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fullName = document.getElementById('regFullName')?.value.trim();
        const email = document.getElementById('regEmail')?.value.trim();
        const role = document.getElementById('regRole')?.value;
        const farmName = document.getElementById('regFarmName')?.value.trim() || 'GreenHorizon Sector 4';
        const password = document.getElementById('regPassword')?.value;
        const submitBtn = document.getElementById('submitRegisterBtn');

        if (!fullName || !email || !password) {
          if (window.App?.toast) App.toast("Please fill in all required fields.", "error");
          return;
        }

        if (password.length < 6) {
          if (window.App?.toast) App.toast("Password must be at least 6 characters.", "error");
          return;
        }

        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Creating Account...';
        }

        try {
          if (window.App && App.isBackendLive) {
            const res = await fetch(`${App.apiBase}/api/auth/signup`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                full_name: fullName,
                email: email,
                password: password,
                role: role,
                farm_name: farmName
              })
            });

            if (res.ok) {
              const data = await res.json();
              this.saveSession(data.user, data.token);
              this.hideModal();
              if (window.App?.toast) App.toast(data.message || `Account created! Welcome, ${fullName}.`, "success");
              return;
            } else {
              const err = await res.json();
              if (window.App?.toast) App.toast(err.detail || "Registration failed.", "error");
              return;
            }
          }
        } catch (err) {
          // Backend offline -> proceed to local registration
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Create Farm Account';
          }
        }

        // Local Offline Registration
        const result = LocalUsers.register({
          full_name: fullName,
          email: email,
          password: password,
          role: role,
          farm_name: farmName
        });

        if (result.ok) {
          this.saveSession(result.user, 'local-token-' + Date.now());
          this.hideModal();
          if (window.App?.toast) {
            App.toast(`Account created! Welcome to Smart Agriculture, ${fullName}.`, "success");
          }
        } else {
          if (window.App?.toast) {
            App.toast(result.error, "error");
          }
        }
      });
    }
  },

  updateHeaderProfile() {
    const widget = document.getElementById('authHeaderWidget');
    if (!widget) return;

    if (this.currentUser) {
      const nameParts = (this.currentUser.full_name || 'Farmer').trim().split(/\s+/);
      const initials = nameParts.length > 1 
        ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
        : nameParts[0].substring(0, 2).toUpperCase();

      const roleDisplay = (this.currentUser.role || 'Farmer').split('/')[0].trim();

      widget.innerHTML = `
        <div style="display:flex; align-items:center; gap:0.5rem; padding:0.25rem 0.6rem; background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-full); box-shadow:0 2px 8px rgba(0,0,0,0.12);">
          <div style="width:30px; height:30px; border-radius:50%; background:linear-gradient(135deg, #10b981, #047857); color:white; font-size:0.75rem; font-weight:700; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
            ${initials}
          </div>
          <div style="line-height:1.2; text-align:left; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
            <div style="font-size:0.8rem; font-weight:700; color:var(--text-primary); text-overflow:ellipsis; overflow:hidden;">${this.currentUser.full_name}</div>
            <div style="font-size:0.68rem; color:var(--primary); font-weight:600;">${roleDisplay}</div>
          </div>
          <button class="btn btn-secondary btn-sm" id="logoutBtn" title="Sign Out" style="padding:0.25rem 0.6rem; font-size:0.75rem; display:flex; align-items:center; gap:0.3rem; border-color:rgba(239,68,68,0.3); color:#ef4444; margin-left:0.2rem;">
            <span>🚪</span> Sign Out
          </button>
        </div>
      `;

      const logoutBtn = document.getElementById('logoutBtn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
          this.clearSession();
          if (window.App?.toast) App.toast("Signed out successfully.", "info");
        });
      }
    } else {
      widget.innerHTML = `
        <button class="btn btn-secondary btn-sm" id="openAuthModalBtn" style="gap:0.35rem;">
          👤 Sign In / Register
        </button>
      `;

      const openBtn = document.getElementById('openAuthModalBtn');
      if (openBtn) {
        openBtn.addEventListener('click', () => this.showModal('login'));
      }
    }
  }
};

window.LocalUsers = LocalUsers;
window.Auth = Auth;
document.addEventListener('DOMContentLoaded', () => Auth.init());
