/**
 * ============================================================================
 * AI Smart Agriculture Assistant - Crop Scanner & Plant Disease Diagnostic Lab
 * Advanced foliar health analysis, crop classification (Vegetables, Fruits,
 * Cereals, Pulses), and precision botanical treatment recovery plans.
 * ============================================================================
 */

const CROP_CATALOG = {
  broccoli: {
    name: 'Broccoli',
    icon: '🥦',
    category: 'Vegetable',
    categoryBadge: '🥬 Vegetable · Cruciferous Cole Crop',
    badgeColor: '#10b981',
    family: 'Brassicaceae (Cruciferous / Mustard Family)',
    botanical: 'Brassica oleracea var. italica',
    nature: 'Cool-season vegetable · Edible immature flower head & stalks',
    nutrition: 'Rich in Vitamin C, Vitamin K, Sulforaphane, Dietary Fiber & Folate',
    climate: '15°C – 22°C · Well-drained fertile loam · pH 6.0 – 6.8',
    care: 'Regular shallow irrigation, balanced N-P-K (prevent Boron deficiency to avoid hollow stems).'
  },
  tomato: {
    name: 'Tomato',
    icon: '🍅',
    category: 'Vegetable',
    categoryBadge: '🥬 Vegetable · Solanaceous Fruiting Vegetable',
    badgeColor: '#ef4444',
    family: 'Solanaceae (Nightshade Family)',
    botanical: 'Solanum lycopersicum',
    nature: 'Warm-season tender fruiting vegetable (culinary vegetable, botanical fruit)',
    nutrition: 'High in Lycopene (potent antioxidant), Vitamin C, Potassium & Vitamin A',
    climate: '21°C – 29°C · Deep loamy soil · pH 6.2 – 6.8',
    care: 'Use drip irrigation to prevent early blight and blossom-end rot (adequate Calcium).'
  },
  potato: {
    name: 'Potato',
    icon: '🥔',
    category: 'Vegetable',
    categoryBadge: '🥔 Tuberous Vegetable · Root & Tuber Crop',
    badgeColor: '#f59e0b',
    family: 'Solanaceae (Nightshade Family)',
    botanical: 'Solanum tuberosum',
    nature: 'Starchy edible stem tuber vegetable · Global staple vegetable',
    nutrition: 'Rich in Complex Carbohydrates, Potassium, Vitamin C & Vitamin B6',
    climate: '15°C – 20°C · Loose, sandy-loam well-aerated soil · pH 5.0 – 6.5',
    care: 'Hill up soil around stems to prevent tuber greening (solanine) and late blight.'
  },
  apple: {
    name: 'Apple',
    icon: '🍎',
    category: 'Fruit',
    categoryBadge: '🍎 Fruit · Deciduous Pomaceous Tree Fruit',
    badgeColor: '#e11d48',
    family: 'Rosaceae (Rose Family)',
    botanical: 'Malus domestica',
    nature: 'Perennial temperate tree fruit · Fleshy pome fruit',
    nutrition: 'High in Dietary Fiber (Pectin), Vitamin C, Potassium & Quercetin antioxidants',
    climate: 'Winter chilling hours (<7°C) · Well-drained rich loam · pH 6.0 – 7.0',
    care: 'Annual canopy pruning for sunlight penetration; preventive fungicide spray for scab at bud-break.'
  },
  rice: {
    name: 'Rice (Paddy)',
    icon: '🌾',
    category: 'Cereal Crop',
    categoryBadge: '🌾 Cereal Crop · Major Food Grain Staple',
    badgeColor: '#3b82f6',
    family: 'Poaceae (Gramineae / Grass Family)',
    botanical: 'Oryza sativa',
    nature: 'Primary cereal food grain crop · Staple food for over half the world',
    nutrition: 'Main source of Dietary Carbohydrates, Clean Energy & B-vitamins',
    climate: '20°C – 37°C · Clayey / heavy soils with high water retention · pH 5.5 – 7.0',
    care: 'Maintain 3–5 cm water depth during tillering; avoid excess nitrogen to prevent leaf blast.'
  },
  wheat: {
    name: 'Wheat',
    icon: '🌾',
    category: 'Cereal Crop',
    categoryBadge: '🌾 Cereal Crop · Major Staple Grain',
    badgeColor: '#d97706',
    family: 'Poaceae (Gramineae / Grass Family)',
    botanical: 'Triticum aestivum',
    nature: 'Cool-season staple cereal grass crop (Rabi season food grain)',
    nutrition: 'Rich in Plant Protein (Gluten), Complex Starches, Fiber, Iron & B-complex',
    climate: '14°C – 24°C · Well-drained fertile loams · pH 6.0 – 7.5',
    care: 'Critical irrigation at Crown Root Initiation (CRI) 21 days after sowing.'
  },
  maize: {
    name: 'Maize (Corn)',
    icon: '🌽',
    category: 'Cereal Crop',
    categoryBadge: '🌽 Cereal Crop · Coarse Grain & C4 Crop',
    badgeColor: '#eab308',
    family: 'Poaceae (Gramineae / Grass Family)',
    botanical: 'Zea mays',
    nature: 'Warm-season highly efficient C4 cereal grain & fodder crop',
    nutrition: 'Loaded with Carotenoids (Lutein & Zeaxanthin for eye health), Fiber & Energy',
    climate: '21°C – 30°C · Deep fertile loam with good organic matter · pH 6.0 – 7.2',
    care: 'Heavy nitrogen feeder; ensure good drainage and scout for fall armyworm.'
  },
  cabbage: {
    name: 'Cabbage',
    icon: '🥬',
    category: 'Vegetable',
    categoryBadge: '🥬 Vegetable · Leafy Cole Vegetable',
    badgeColor: '#10b981',
    family: 'Brassicaceae (Cruciferous / Mustard Family)',
    botanical: 'Brassica oleracea var. capitata',
    nature: 'Cool-season vegetable forming dense edible leafy head',
    nutrition: 'Rich in Vitamin C, Vitamin K, Anthocyanins & Glucosinolates',
    climate: '15°C – 20°C · Moisture-retentive loamy soil · pH 6.0 – 6.8',
    care: 'Mulch to preserve uniform soil moisture; rotate crops to prevent clubroot disease.'
  },
  cauliflower: {
    name: 'Cauliflower',
    icon: '🥦',
    category: 'Vegetable',
    categoryBadge: '🥬 Vegetable · Cole Vegetable (Curd)',
    badgeColor: '#10b981',
    family: 'Brassicaceae (Cruciferous / Mustard Family)',
    botanical: 'Brassica oleracea var. botrytis',
    nature: 'Cool-season edible floral curd vegetable',
    nutrition: 'High in Choline, Vitamin C, Vitamin K & Antioxidants',
    climate: '16°C – 20°C · Deep fertile loam · pH 6.0 – 7.0',
    care: 'Tie outer leaves over developing curds (blanching) to maintain spotless white curds.'
  },
  chilli: {
    name: 'Green Chilli',
    icon: '🌶️',
    category: 'Spice / Vegetable',
    categoryBadge: '🌶️ Spice & Vegetable · Pungent Pod Crop',
    badgeColor: '#ef4444',
    family: 'Solanaceae (Nightshade Family)',
    botanical: 'Capsicum annuum',
    nature: 'Warm-season pungent pod used both as fresh vegetable and spice',
    nutrition: 'Extremely rich in Vitamin C (more than oranges), Capsaicin & Beta-carotene',
    climate: '20°C – 32°C · Light well-drained loam · pH 6.5 – 7.5',
    care: 'Avoid excess nitrogen during flowering; control thrips and mites to prevent leaf curl virus.'
  },
  onion: {
    name: 'Onion',
    icon: '🧅',
    category: 'Vegetable',
    categoryBadge: '🧅 Vegetable · Bulb Vegetable & Seasoning',
    badgeColor: '#a855f7',
    family: 'Amaryllidaceae (Alliaceae / Onion Family)',
    botanical: 'Allium cepa',
    nature: 'Biennial grown as annual for underground edible layered bulbs',
    nutrition: 'Packed with Quercetin, Allyl Propyl Disulfide (sulfur compounds) & Prebiotics',
    climate: '13°C – 24°C · Light, friable sandy-loam · pH 6.0 – 6.8',
    care: 'Keep weed-free (shallow roots); stop watering 12 days before harvest for proper bulb curing.'
  },
  carrot: {
    name: 'Carrot',
    icon: '🥕',
    category: 'Vegetable',
    categoryBadge: '🥕 Vegetable · Root Vegetable',
    badgeColor: '#f97316',
    family: 'Apiaceae (Umbelliferae / Carrot Family)',
    botanical: 'Daucus carota subsp. sativus',
    nature: 'Root vegetable grown for its sweet, crisp taproot',
    nutrition: 'Outstanding source of Beta-Carotene (Provitamin A), Lutein & Dietary Fiber',
    climate: '16°C – 20°C · Deep, loose, stone-free sandy soil · pH 6.0 – 6.8',
    care: 'Soil must be loose and free of rocks to prevent forking or crooked taproots.'
  },
  mango: {
    name: 'Mango',
    icon: '🥭',
    category: 'Fruit',
    categoryBadge: '🥭 Fruit · Tropical King of Fruits',
    badgeColor: '#f97316',
    family: 'Anacardiaceae (Cashew Family)',
    botanical: 'Mangifera indica',
    nature: 'Evergreen perennial tropical tree fruit (National fruit of India)',
    nutrition: 'Superb source of Vitamin A, Vitamin C, Folate & Digestive Enzymes (Amylases)',
    climate: '24°C – 32°C · Deep alluvial or rich loamy soil · pH 5.5 – 7.5',
    care: 'Withhold irrigation before flowering to induce profuse flower panicles.'
  },
  banana: {
    name: 'Banana',
    icon: '🍌',
    category: 'Fruit',
    categoryBadge: '🍌 Fruit · Tropical Giant Herbaceous Fruit',
    badgeColor: '#eab308',
    family: 'Musaceae (Banana Family)',
    botanical: 'Musa acuminata / paradisiaca',
    nature: 'Large perennial monocot herb producing edible hanging berry clusters',
    nutrition: 'High in Potassium, Vitamin B6, Vitamin C & Fast-acting Healthy Energy',
    climate: '22°C – 35°C · Heavy feeding soil with high drainage · pH 6.0 – 7.5',
    care: 'Provide heavy Potash (K) fertilizer and wind propping (bamboo poles) for heavy bunches.'
  },
  pulse: {
    name: 'Chickpea / Moong (Pulses)',
    icon: '🫘',
    category: 'Pulse / Legume',
    categoryBadge: '🫘 Pulse · Grain Legume & Nitrogen Fixer',
    badgeColor: '#8b5cf6',
    family: 'Fabaceae (Leguminosae / Bean Family)',
    botanical: 'Cicer arietinum / Vigna radiata',
    nature: 'Food grain pulse crop · Natural soil-enriching nitrogen fixer',
    nutrition: 'High in Plant Protein (22–24%), Complex Fiber, Iron, Folate & Zinc',
    climate: '15°C – 28°C · Well-drained loams with moderate moisture · pH 6.0 – 8.0',
    care: 'Inoculate seed with Rhizobium bio-fertilizer; avoid waterlogged fields.'
  },
  mustard: {
    name: 'Mustard',
    icon: '🌻',
    category: 'Oilseed Crop',
    categoryBadge: '🌻 Oilseed · Winter Cash Crop',
    badgeColor: '#eab308',
    family: 'Brassicaceae (Cruciferous / Mustard Family)',
    botanical: 'Brassica juncea',
    nature: 'Winter oilseed crop grown for edible cooking oil and seeds',
    nutrition: 'Rich in Healthy MUFA (Omega-3/6), Glucosinolates & Antioxidants',
    climate: '15°C – 25°C · Loam to clay-loam soils · pH 6.0 – 7.5',
    care: 'Ensure timely sowing in October; monitor for mustard aphid during flowering.'
  }
};

/* ---------- Extra crops (so almost everything can be scanned) ---------- */
(function () {
  const add = (k, icon, name, category, family, botanical, nature, nutrition, climate, care, color) =>
    CROP_CATALOG[k] = { name, icon, category, categoryBadge: `${icon} ${category}`, badgeColor: color || '#10b981', family, botanical, nature, nutrition, climate, care };
  add('generic', '🌿', 'Unidentified Plant', 'Unknown', '—', '—', 'Crop not identified automatically. Pick the right crop from the list for crop-specific advice.', 'Varies by crop', 'Varies by crop', 'General advice: balanced watering, clean field, weekly scouting.', '#64748b');
  add('cucumber', '🥒', 'Cucumber', 'Vegetable', 'Cucurbitaceae', 'Cucumis sativus', 'Warm-season trailing vine vegetable', 'Hydrating, Vitamin K, Potassium', '20–30°C · Sandy loam · pH 6.0–7.0', 'Trellis the vines; avoid wetting leaves (downy/powdery mildew).', '#22c55e');
  add('brinjal', '🍆', 'Brinjal (Eggplant)', 'Vegetable', 'Solanaceae', 'Solanum melongena', 'Warm-season fruiting vegetable', 'Fibre, Manganese, Anthocyanins', '22–30°C · Rich loam · pH 5.5–6.8', 'Watch for shoot & fruit borer; use pheromone traps.', '#7c3aed');
  add('okra', '🌱', 'Okra (Bhindi)', 'Vegetable', 'Malvaceae', 'Abelmoschus esculentus', 'Warm-season pod vegetable', 'Fibre, Vitamin C, Folate', '24–35°C · Well-drained loam · pH 6.0–6.8', 'Control whitefly (yellow vein mosaic); pick pods every 2 days.', '#16a34a');
  add('capsicum', '🫑', 'Capsicum (Bell Pepper)', 'Vegetable', 'Solanaceae', 'Capsicum annuum var. grossum', 'Mild-flavoured fruiting vegetable', 'Vitamin C, Vitamin A', '20–28°C · Loam · pH 6.0–6.8', 'Mulch and drip irrigate; shade net in peak summer.', '#ef4444');
  add('spinach', '🥬', 'Spinach (Palak)', 'Vegetable', 'Amaranthaceae', 'Spinacia oleracea', 'Cool-season leafy vegetable', 'Iron, Folate, Vitamin K', '10–22°C · Fertile loam · pH 6.5–7.5', 'Light, frequent irrigation; nitrogen boosts leaf growth.', '#16a34a');
  add('garlic', '🧄', 'Garlic', 'Vegetable', 'Amaryllidaceae', 'Allium sativum', 'Cool-season bulb crop', 'Allicin, Manganese, Vitamin B6', '12–24°C · Loose loam · pH 6.0–7.0', 'Stop irrigation 2 weeks before harvest; cure bulbs in shade.', '#a855f7');
  add('peas', '🫛', 'Green Peas (Matar)', 'Vegetable', 'Fabaceae', 'Pisum sativum', 'Cool-season legume vegetable', 'Protein, Fibre, Vitamin K', '10–20°C · Loam · pH 6.0–7.5', 'Avoid waterlogging; control powdery mildew.', '#22c55e');
  add('pumpkin', '🎃', 'Pumpkin / Gourd', 'Vegetable', 'Cucurbitaceae', 'Cucurbita spp.', 'Warm-season trailing vegetable', 'Beta-carotene, Fibre', '22–32°C · Loam · pH 6.0–7.0', 'Wide spacing; keep fruit off wet soil.', '#f97316');
  add('sugarcane', '🎋', 'Sugarcane', 'Cash Crop', 'Poaceae', 'Saccharum officinarum', 'Tall perennial grass grown for sugar', 'Sucrose, Jaggery, Ethanol', '20–35°C · Deep loam · pH 6.5–7.5', 'Trash mulching; earthing-up; ratoon management.', '#84cc16');
  add('cotton', '☁️', 'Cotton', 'Cash Crop', 'Malvaceae', 'Gossypium hirsutum', 'Fibre crop', 'Fibre & cottonseed oil', '21–30°C · Black / alluvial soil · pH 6.0–8.0', 'Scout for pink bollworm & whitefly weekly.', '#94a3b8');
  add('soybean', '🫘', 'Soybean', 'Pulse / Oilseed', 'Fabaceae', 'Glycine max', 'Kharif legume & oilseed', 'Protein 40%, Oil 20%', '20–30°C · Well-drained loam · pH 6.0–7.0', 'Rhizobium seed treatment; avoid waterlogging.', '#8b5cf6');
  add('groundnut', '🥜', 'Groundnut', 'Oilseed Crop', 'Fabaceae', 'Arachis hypogaea', 'Kharif oilseed legume', 'Protein, Healthy fats', '25–30°C · Sandy loam · pH 6.0–6.5', 'Gypsum at pegging stage; prevent leaf spot.', '#d97706');
  add('orange', '🍊', 'Orange / Kinnow', 'Fruit', 'Rutaceae', 'Citrus sinensis / reticulata', 'Evergreen citrus tree fruit', 'Vitamin C, Flavonoids', '15–30°C · Well-drained loam · pH 6.0–7.5', 'Drip irrigation; control citrus canker & psylla.', '#f97316');
  add('lemon', '🍋', 'Lemon', 'Fruit', 'Rutaceae', 'Citrus limon', 'Evergreen citrus tree', 'Vitamin C, Citric acid', '20–30°C · Light loam · pH 5.5–7.0', 'Prune dead twigs; watch for canker.', '#eab308');
  add('grape', '🍇', 'Grapes', 'Fruit', 'Vitaceae', 'Vitis vinifera', 'Perennial climbing vine fruit', 'Resveratrol, Vitamin K', '15–35°C · Well-drained loam · pH 6.5–7.0', 'Canopy pruning; downy mildew control in humid weather.', '#7c3aed');
  add('pomegranate', '🍎', 'Pomegranate', 'Fruit', 'Lythraceae', 'Punica granatum', 'Dry-climate fruit shrub', 'Punicalagin, Vitamin C', '25–35°C · Light loam · pH 6.5–7.5', 'Drip irrigation; bagging fruits prevents bacterial blight.', '#be123c');
  add('papaya', '🍈', 'Papaya', 'Fruit', 'Caricaceae', 'Carica papaya', 'Fast-growing tropical fruit tree', 'Papain, Vitamin C, Vitamin A', '22–32°C · Well-drained loam · pH 6.0–7.0', 'Never let water stand at the stem; control papaya ring-spot virus vectors.', '#f59e0b');
  add('guava', '🍐', 'Guava', 'Fruit', 'Myrtaceae', 'Psidium guajava', 'Hardy tropical fruit tree', 'Vitamin C (very high), Fibre', '23–28°C · Any well-drained soil · pH 5.5–7.5', 'Prune after harvest; fruit-fly traps.', '#84cc16');
  add('watermelon', '🍉', 'Watermelon', 'Fruit', 'Cucurbitaceae', 'Citrullus lanatus', 'Warm-season vine fruit', 'Hydration, Lycopene', '24–35°C · Sandy loam · pH 6.0–7.0', 'Reduce water before harvest for sweetness.', '#16a34a');
  add('strawberry', '🍓', 'Strawberry', 'Fruit', 'Rosaceae', 'Fragaria × ananassa', 'Low-growing berry plant', 'Vitamin C, Manganese', '15–25°C · Sandy loam · pH 5.5–6.5', 'Plastic mulch keeps fruit clean; control grey mould.', '#e11d48');
  add('turmeric', '🟡', 'Turmeric / Ginger', 'Spice', 'Zingiberaceae', 'Curcuma longa / Zingiber officinale', 'Rhizome spice crop', 'Curcumin, Gingerol', '20–30°C · Rich loam · pH 5.5–7.0', 'Mulch heavily; avoid waterlogging (rhizome rot).', '#eab308');
  add('coriander', '🌿', 'Coriander', 'Spice / Leafy', 'Apiaceae', 'Coriandrum sativum', 'Cool-season herb & seed spice', 'Vitamin K, Antioxidants', '15–25°C · Loam · pH 6.5–7.5', 'Sow densely; protect from powdery mildew.', '#22c55e');
})();

const HI = { generic: 'अज्ञात पौधा', broccoli: 'ब्रोकली', tomato: 'टमाटर', potato: 'आलू', apple: 'सेब', rice: 'धान (चावल)', wheat: 'गेहूं', maize: 'मक्का', cabbage: 'पत्ता गोभी', cauliflower: 'फूल गोभी', chilli: 'हरी मिर्च', onion: 'प्याज', carrot: 'गाजर', mango: 'आम', banana: 'केला', pulse: 'दलहन (चना/मूंग)', mustard: 'सरसों', cucumber: 'खीरा', brinjal: 'बैंगन', okra: 'भिंडी', capsicum: 'शिमला मिर्च', spinach: 'पालक', garlic: 'लहसुन', peas: 'मटर', pumpkin: 'कद्दू', sugarcane: 'गन्ना', cotton: 'कपास', soybean: 'सोयाबीन', groundnut: 'मूंगफली', orange: 'संतरा/किन्नू', lemon: 'नींबू', grape: 'अंगूर', pomegranate: 'अनार', papaya: 'पपीता', guava: 'अमरूद', watermelon: 'तरबूज', strawberry: 'स्ट्रॉबेरी', turmeric: 'हल्दी/अदरक', coriander: 'धनिया' };

/* Crop-specific disease names: [English, Hindi, pathogen, organic, chemical] */
const DIS = {
  tomato: ['Early Blight', 'अगेती झुलसा', 'Fungus (Alternaria solani)', 'Neem oil 5 ml/L or Trichoderma 5 g/L every 7 days; remove lower infected leaves.', 'Mancozeb 75% WP 2.5 g/L or Chlorothalonil; alternate with Difenoconazole.'],
  potato: ['Late Blight', 'पछेता झुलसा', 'Oomycete (Phytophthora infestans)', 'Bordeaux mixture 1% spray; destroy infected plants.', 'Metalaxyl + Mancozeb 2 g/L or Cymoxanil + Mancozeb 3 g/L immediately.'],
  rice: ['Leaf Blast', 'झोंका रोग', 'Fungus (Magnaporthe oryzae)', 'Pseudomonas fluorescens spray; avoid excess nitrogen.', 'Tricyclazole 75% WP 0.6 g/L or Isoprothiolane 1.5 ml/L.'],
  maize: ['Northern Leaf Blight', 'पत्ती झुलसा', 'Fungus (Exserohilum turcicum)', 'Bacillus subtilis spray; remove crop residue.', 'Azoxystrobin + Difenoconazole 1 ml/L at tasseling.'],
  wheat: ['Leaf / Yellow Rust', 'रतुआ (रस्ट)', 'Fungus (Puccinia spp.)', 'Spray cow-urine / neem extract early; grow resistant varieties.', 'Propiconazole 25% EC 1 ml/L, repeat after 15 days.'],
  apple: ['Apple Scab', 'सेब का स्कैब', 'Fungus (Venturia inaequalis)', 'Sulphur spray at bud swell; rake and destroy fallen leaves.', 'Captan 2.5 g/L or Difenoconazole 0.3 ml/L.'],
  chilli: ['Anthracnose / Leaf Spot', 'एन्थ्रेक्नोज़', 'Fungus (Colletotrichum)', 'Neem oil 5 ml/L; use disease-free seed.', 'Carbendazim 1 g/L or Azoxystrobin 1 ml/L.'],
  cabbage: ['Alternaria Leaf Spot / Black Rot', 'काला सड़न / पत्ती धब्बा', 'Fungus / Bacterium (Alternaria, Xanthomonas)', 'Hot-water treated seed; copper oxychloride 3 g/L.', 'Mancozeb 2.5 g/L; Streptocycline 0.1 g/L for black rot.'],
  broccoli: ['Alternaria Leaf Spot', 'अल्टरनेरिया पत्ती धब्बा', 'Fungus (Alternaria brassicae)', 'Neem oil 5 ml/L; rotate crops.', 'Mancozeb 2.5 g/L or Iprodione 2 g/L.'],
  cauliflower: ['Black Rot / Leaf Spot', 'काला सड़न', 'Bacterium (Xanthomonas campestris)', 'Copper oxychloride 3 g/L; seed treatment.', 'Streptocycline 0.1 g/L + Copper oxychloride.'],
  mango: ['Anthracnose', 'एन्थ्रेक्नोज़', 'Fungus (Colletotrichum gloeosporioides)', 'Prune infected twigs; Trichoderma spray.', 'Carbendazim 1 g/L or Copper oxychloride 3 g/L at flowering.'],
  banana: ['Sigatoka Leaf Spot', 'सिगाटोका पत्ती धब्बा', 'Fungus (Mycosphaerella)', 'Remove spotted leaves; Neem oil 5 ml/L.', 'Propiconazole 1 ml/L or Mancozeb 2.5 g/L.'],
  onion: ['Purple Blotch', 'पर्पल ब्लॉच', 'Fungus (Alternaria porri)', 'Neem oil; wide spacing; avoid overhead watering.', 'Mancozeb 2.5 g/L or Tebuconazole 1 ml/L.'],
  mustard: ['Alternaria Blight', 'अल्टरनेरिया झुलसा', 'Fungus (Alternaria brassicae)', 'Timely sowing; Trichoderma seed treatment.', 'Mancozeb 2.5 g/L, 2 sprays 15 days apart.'],
  pulse: ['Wilt / Ascochyta Blight', 'उकठा / झुलसा', 'Fungus (Fusarium / Ascochyta)', 'Trichoderma soil application; resistant varieties.', 'Carbendazim seed treatment 2 g/kg.'],
  cucumber: ['Downy / Powdery Mildew', 'मृदुरोमिल / चूर्णिल आसिता', 'Oomycete / Fungus', 'Milk spray 1:9 or sulphur 2 g/L; trellis the vines.', 'Metalaxyl + Mancozeb 2 g/L (downy); Hexaconazole 1 ml/L (powdery).'],
  brinjal: ['Phomopsis Blight / Little Leaf', 'फोमोप्सिस झुलसा', 'Fungus (Phomopsis vexans)', 'Remove infected parts; Neem oil.', 'Carbendazim 1 g/L or Mancozeb 2.5 g/L.'],
  okra: ['Cercospora Leaf Spot / Yellow Vein Mosaic', 'पीला शिरा रोग', 'Fungus / Virus (whitefly-borne)', 'Yellow sticky traps; neem oil for whitefly.', 'Imidacloprid 0.3 ml/L for whitefly; Mancozeb for leaf spot.'],
  grape: ['Downy Mildew', 'मृदुरोमिल आसिता', 'Oomycete (Plasmopara viticola)', 'Bordeaux mixture 1%; canopy opening.', 'Metalaxyl + Mancozeb 2 g/L.'],
  pomegranate: ['Bacterial Blight / Leaf Spot', 'जीवाणु झुलसा', 'Bacterium (Xanthomonas axonopodis)', 'Copper oxychloride 3 g/L; fruit bagging.', 'Streptocycline 0.5 g/L + Copper oxychloride.'],
  orange: ['Citrus Canker', 'नींबू कैंकर', 'Bacterium (Xanthomonas citri)', 'Prune infected twigs; Bordeaux paste.', 'Copper oxychloride 3 g/L + Streptocycline 0.5 g/L.'],
  groundnut: ['Tikka Leaf Spot', 'टिक्का रोग', 'Fungus (Cercospora)', 'Neem seed extract 5%; crop rotation.', 'Chlorothalonil 2 g/L or Hexaconazole 1 ml/L.'],
  soybean: ['Rust / Frogeye Leaf Spot', 'रतुआ', 'Fungus', 'Resistant varieties; neem oil.', 'Hexaconazole 1 ml/L or Tebuconazole 1 ml/L.'],
  cotton: ['Alternaria / Grey Mildew Leaf Spot', 'पत्ती धब्बा', 'Fungus', 'Neem oil; balanced potash.', 'Copper oxychloride 3 g/L or Mancozeb 2.5 g/L.'],
  sugarcane: ['Red Rot / Leaf Spot', 'लाल सड़न', 'Fungus (Colletotrichum falcatum)', 'Use healthy setts; hot-water treatment.', 'Carbendazim 1 g/L sett dip.']
};

/* Generic diagnosis text. en + hi. */
const TX = {
  en: {
    healthy: { n: 'Healthy', p: 'No disease detected', s: 'Uniform green colour, no spots or yellowing. Plant looks vigorous.', o: 'No spray needed. Seaweed extract 2 ml/L or vermiwash 1:10 every 15 days keeps plants strong.', c: 'No chemical needed.', v: 'Keep regular watering, balanced NPK and weekly scouting.',
      st: [['Now', 'Nothing to treat. Keep the current watering schedule.'], ['Weekly', 'Scan a leaf every 7–10 days, especially after rain.'], ['Every 15 days', 'Spray vermiwash / seaweed extract for vigour.'], ['Always', 'Remove weeds and keep tools clean.']] },
    chlorosis: { n: 'Yellowing (Nutrient / Water Stress)', p: 'Nitrogen / Iron deficiency or over-watering', s: 'Leaves turning pale-yellow while veins stay green. Often caused by poor drainage or low nitrogen/iron.', o: 'Vermicompost 2 kg/plant or Jeevamrut drench; seaweed spray 3 ml/L.', c: 'Foliar urea 1% (10 g/L) for nitrogen, or chelated iron / FeSO₄ 0.5% for iron deficiency.', v: 'Improve drainage, test soil pH & NPK, avoid standing water.',
      st: [['Day 0', 'Check soil: if soggy, stop irrigation and loosen the soil around roots.'], ['Day 1', 'Add compost / vermicompost around the plant (not touching the stem).'], ['Day 2–3', 'Evening foliar spray: 1% urea or micronutrient mix.'], ['Day 7', 'Re-scan. New leaves should look greener. Repeat spray once if still pale.'], ['Day 14', 'If yellowing continues, test soil pH and check roots for rot / nematodes.']] },
    spot: { n: 'Leaf Spot / Blight', p: 'Fungal / bacterial infection', s: 'Brown or dark spots with yellow halo spreading on the leaf; leaves may dry and drop.', o: 'Remove infected leaves. Neem oil 5 ml/L or Trichoderma viride 5 g/L every 7 days.', c: 'Mancozeb 75% WP 2.5 g/L or Azoxystrobin 1 ml/L; repeat after 10 days (follow label).', v: 'Drip irrigation, keep leaves dry, good spacing, crop rotation.',
      st: [['Day 0', 'Remove and burn badly infected leaves. Disinfect scissors with alcohol.'], ['Day 0', 'Stop overhead watering; water only at the root, in the morning.'], ['Day 1', 'Spray fungicide in the evening, covering the underside of leaves.'], ['Day 7–10', 'Second spray (rotate to a different product). Add potash for resistance.'], ['Day 14', 'Re-scan. If new leaves are clean, recovery is on track.']] },
    rust: { n: 'Rust (Orange pustules)', p: 'Rust fungus (Puccinia / Uromyces)', s: 'Orange-brown powdery pustules on leaves; leaves weaken and dry early.', o: 'Neem oil 5 ml/L or sulphur 2 g/L; remove infected leaves.', c: 'Propiconazole 25% EC 1 ml/L or Tebuconazole 1 ml/L; repeat after 15 days.', v: 'Use resistant varieties, avoid late sowing, keep field airy.',
      st: [['Day 0', 'Remove heavily rusted leaves and bury or burn them.'], ['Day 1', 'Spray sulphur / neem (organic) or Propiconazole (chemical).'], ['Day 10–15', 'Repeat spray.'], ['Day 20', 'Re-scan; healthy new growth means the infection has stopped.']] },
    fresh: { n: 'Fresh & Good Quality', p: 'No spoilage detected', s: 'Clean colour, no dark rotten patches.', o: 'Store cool (10–15°C) and dry; sort daily.', c: 'No treatment needed.', v: 'Harvest in the morning, avoid bruising, keep ventilated.',
      st: [['Now', 'Sell or store soon for best price.'], ['Storage', 'Keep in a cool, ventilated place away from sunlight.'], ['Daily', 'Remove any soft or damaged piece so it does not spoil the rest.']] },
    minor: { n: 'Minor Blemish / Early Spoilage', p: 'Bruising, early fungal rot or insect damage', s: 'Some dark or brown patches on the produce.', o: 'Cut away damaged parts; wipe with diluted vinegar (1:10); dry in shade.', c: 'Post-harvest dip: Carbendazim 0.1% for 2 min (where permitted).', v: 'Careful handling, harvest at right maturity, avoid wet storage.',
      st: [['Today', 'Separate the affected pieces from healthy produce.'], ['Today', 'Sell the good lot quickly or process (pickle / dry / pulp).'], ['Storage', 'Keep dry and ventilated; check every day.']] },
    rot: { n: 'Rotting / Heavy Spoilage', p: 'Fungal / bacterial rot', s: 'Large dark, soft or mouldy areas.', o: 'Discard rotten pieces far from the field (compost only if hot-composted).', c: 'Do not use rotten produce for sale or food.', v: 'Fix drainage, avoid fruit touching soil, harvest on time, cool storage.',
      st: [['Now', 'Remove and discard all rotten pieces; wash hands and crates.'], ['Today', 'Check remaining stock piece by piece.'], ['Field', 'Inspect the plant: check for pests, over-watering and fungal infection.'], ['Next lot', 'Spray preventive fungicide / neem before the next harvest.']] },
    none: { n: 'Plant not clearly detected', p: '—', s: 'Photo has too little plant, fruit or vegetable area. Fill the frame with the leaf or produce in daylight.' }
  },
  hi: {
    healthy: { n: 'स्वस्थ', p: 'कोई रोग नहीं मिला', s: 'एकसमान हरा रंग, कोई धब्बा या पीलापन नहीं। पौधा मज़बूत दिखता है।', o: 'किसी स्प्रे की ज़रूरत नहीं। हर 15 दिन में सीवीड एक्सट्रैक्ट 2 मिली/लीटर या वर्मीवॉश (1:10) डालें।', c: 'रसायन की ज़रूरत नहीं।', v: 'नियमित सिंचाई, संतुलित NPK और हर हफ्ते निरीक्षण करें।',
      st: [['अभी', 'इलाज की ज़रूरत नहीं। सिंचाई का वर्तमान समय जारी रखें।'], ['हर हफ्ते', 'हर 7–10 दिन में पत्ती स्कैन करें, खासकर बारिश के बाद।'], ['हर 15 दिन', 'ताकत के लिए वर्मीवॉश / सीवीड स्प्रे करें।'], ['हमेशा', 'खरपतवार हटाएं और औज़ार साफ रखें।']] },
    chlorosis: { n: 'पीलापन (पोषक तत्व / पानी की कमी या अधिकता)', p: 'नाइट्रोजन / आयरन की कमी या ज़्यादा पानी', s: 'नसें हरी रहती हैं पर पत्तियां पीली पड़ जाती हैं। अक्सर खराब जल निकास या नाइट्रोजन/आयरन की कमी से।', o: 'वर्मीकम्पोस्ट 2 किलो/पौधा या जीवामृत दें; सीवीड स्प्रे 3 मिली/लीटर।', c: 'नाइट्रोजन के लिए यूरिया 1% (10 ग्राम/लीटर) स्प्रे, या आयरन के लिए FeSO₄ 0.5%।', v: 'जल निकास सुधारें, मिट्टी की pH और NPK जांचें, पानी जमा न होने दें।',
      st: [['दिन 0', 'मिट्टी देखें: ज़्यादा गीली हो तो सिंचाई रोकें और जड़ों के पास मिट्टी ढीली करें।'], ['दिन 1', 'पौधे के चारों ओर (तने से दूर) कम्पोस्ट / वर्मीकम्पोस्ट डालें।'], ['दिन 2–3', 'शाम को 1% यूरिया या सूक्ष्म पोषक तत्व का छिड़काव करें।'], ['दिन 7', 'दोबारा स्कैन करें। नई पत्तियां हरी होनी चाहिए। ज़रूरत हो तो एक बार फिर स्प्रे करें।'], ['दिन 14', 'पीलापन न जाए तो मिट्टी की pH और जड़ों (सड़न/सूत्रकृमि) की जांच करें।']] },
    spot: { n: 'पत्ती धब्बा / झुलसा रोग', p: 'फफूंद / जीवाणु संक्रमण', s: 'पत्तियों पर पीले घेरे के साथ भूरे या काले धब्बे फैलते हैं; पत्तियां सूखकर गिर सकती हैं।', o: 'संक्रमित पत्तियां हटाएं। नीम तेल 5 मिली/लीटर या ट्राइकोडर्मा 5 ग्राम/लीटर हर 7 दिन में।', c: 'मैंकोज़ेब 75% WP 2.5 ग्राम/लीटर या एज़ोक्सीस्ट्रोबिन 1 मिली/लीटर; 10 दिन बाद दोहराएं (लेबल देखें)।', v: 'ड्रिप सिंचाई, पत्तियां सूखी रखें, उचित दूरी और फसल चक्र अपनाएं।',
      st: [['दिन 0', 'ज़्यादा संक्रमित पत्तियां तोड़कर जला दें। कैंची को अल्कोहल से साफ करें।'], ['दिन 0', 'ऊपर से पानी देना बंद करें; सुबह सिर्फ जड़ में पानी दें।'], ['दिन 1', 'शाम को फफूंदनाशक छिड़कें, पत्तियों के नीचे की तरफ भी।'], ['दिन 7–10', 'दूसरा स्प्रे (दूसरी दवा से)। रोग-प्रतिरोध के लिए पोटाश दें।'], ['दिन 14', 'दोबारा स्कैन करें। नई पत्तियां साफ हों तो सुधार हो रहा है।']] },
    rust: { n: 'रतुआ (नारंगी फफोले)', p: 'रस्ट फफूंद (Puccinia / Uromyces)', s: 'पत्तियों पर नारंगी-भूरे पाउडर जैसे फफोले; पत्तियां कमज़ोर होकर जल्दी सूखती हैं।', o: 'नीम तेल 5 मिली/लीटर या सल्फर 2 ग्राम/लीटर; संक्रमित पत्तियां हटाएं।', c: 'प्रोपिकोनाज़ोल 25% EC 1 मिली/लीटर या टेबुकोनाज़ोल 1 मिली/लीटर; 15 दिन बाद दोहराएं।', v: 'रोग-रोधी किस्में लगाएं, देर से बुवाई न करें, खेत में हवा आने दें।',
      st: [['दिन 0', 'ज़्यादा रस्ट वाली पत्तियां हटाकर दबा दें या जला दें।'], ['दिन 1', 'सल्फर / नीम (जैविक) या प्रोपिकोनाज़ोल (रासायनिक) छिड़कें।'], ['दिन 10–15', 'स्प्रे दोहराएं।'], ['दिन 20', 'दोबारा स्कैन करें; नई स्वस्थ बढ़त मतलब रोग रुक गया।']] },
    fresh: { n: 'ताज़ा और अच्छी गुणवत्ता', p: 'सड़न नहीं मिली', s: 'साफ रंग, कोई सड़े काले धब्बे नहीं।', o: 'ठंडी (10–15°C) और सूखी जगह रखें; रोज़ छांटें।', c: 'इलाज की ज़रूरत नहीं।', v: 'सुबह तुड़ाई करें, चोट न लगने दें, हवादार जगह रखें।',
      st: [['अभी', 'अच्छे भाव के लिए जल्दी बेचें या स्टोर करें।'], ['भंडारण', 'ठंडी, हवादार जगह रखें, धूप से दूर।'], ['रोज़', 'कोई नरम या खराब दाना/फल हो तो अलग करें ताकि बाकी खराब न हों।']] },
    minor: { n: 'हल्के दाग / शुरुआती खराबी', p: 'चोट, शुरुआती फफूंद सड़न या कीट नुकसान', s: 'उपज पर कुछ काले या भूरे धब्बे हैं।', o: 'खराब हिस्सा काटें; हल्के सिरके (1:10) से पोंछें; छांव में सुखाएं।', c: 'तुड़ाई के बाद कार्बेन्डाज़िम 0.1% में 2 मिनट डुबोएं (जहां अनुमति हो)।', v: 'सावधानी से संभालें, सही परिपक्वता पर तोड़ें, गीला भंडारण न करें।',
      st: [['आज', 'प्रभावित टुकड़ों को स्वस्थ उपज से अलग करें।'], ['आज', 'अच्छा माल जल्दी बेचें या प्रोसेस करें (अचार / सुखाना / पल्प)।'], ['भंडारण', 'सूखा और हवादार रखें; रोज़ जांचें।']] },
    rot: { n: 'सड़न / भारी खराबी', p: 'फफूंद / जीवाणु सड़न', s: 'बड़े काले, नरम या फफूंद लगे हिस्से।', o: 'सड़े हिस्से खेत से दूर फेंकें (गर्म कम्पोस्ट में ही डालें)।', c: 'सड़ी उपज बेचें या खाएं नहीं।', v: 'जल निकास सुधारें, फल को मिट्टी से न छूने दें, समय पर तुड़ाई, ठंडा भंडारण।',
      st: [['अभी', 'सारे सड़े टुकड़े हटाकर फेंकें; हाथ और क्रेट धोएं।'], ['आज', 'बचा माल एक-एक करके जांचें।'], ['खेत', 'पौधे की जांच करें: कीट, ज़्यादा पानी और फफूंद संक्रमण देखें।'], ['अगली तुड़ाई', 'अगली तुड़ाई से पहले बचाव में फफूंदनाशक / नीम का छिड़काव करें।']] },
    none: { n: 'पौधा साफ नहीं दिखा', p: '—', s: 'फोटो में पत्ती, फल या सब्ज़ी का हिस्सा बहुत कम है। दिन की रोशनी में पत्ती/उपज को फ्रेम में भरकर फोटो लें।' }
  }
};

const SAMPLES = {
  'TOM-EB-01': { crop: 'tomato', m: { green: 60, yellow: 14, lesion: 26 } },
  'POT-LB-02': { crop: 'potato', m: { green: 45, yellow: 10, lesion: 45 } },
  'RIC-BL-03': { crop: 'rice', m: { green: 62, yellow: 14, lesion: 24 } },
  'CRN-NL-04': { crop: 'maize', m: { green: 66, yellow: 12, lesion: 22 } },
  'APP-SC-05': { crop: 'apple', m: { green: 70, yellow: 8, lesion: 22 } },
  'PLT-HL-00': { crop: 'generic', m: { green: 97, yellow: 2, lesion: 1 } }
};

const IMAGENET = { broccoli: 'broccoli', cauliflower: 'cauliflower', 'head cabbage': 'cabbage', cucumber: 'cucumber', zucchini: 'cucumber', 'bell pepper': 'capsicum', banana: 'banana', orange: 'orange', lemon: 'lemon', strawberry: 'strawberry', pomegranate: 'pomegranate', 'granny smith': 'apple', corn: 'maize', ear: 'maize', 'acorn squash': 'pumpkin', 'butternut squash': 'pumpkin', 'spaghetti squash': 'pumpkin', fig: 'guava', custard: 'guava', mushroom: 'generic', artichoke: 'cabbage', jackfruit: 'papaya', pineapple: 'papaya' };
const ALIASES = { tamatar: 'tomato', aloo: 'potato', dhan: 'rice', paddy: 'rice', gehu: 'wheat', gehun: 'wheat', bhutta: 'maize', corn: 'maize', gobi: 'cauliflower', mirch: 'chilli', chili: 'chilli', pepper: 'capsicum', pyaz: 'onion', gajar: 'carrot', aam: 'mango', kela: 'banana', chana: 'pulse', moong: 'pulse', dal: 'pulse', sarson: 'mustard', kheera: 'cucumber', baingan: 'brinjal', bhindi: 'okra', palak: 'spinach', lahsun: 'garlic', matar: 'peas', kaddu: 'pumpkin', ganna: 'sugarcane', kapas: 'cotton', moongfali: 'groundnut', peanut: 'groundnut', santra: 'orange', kinnow: 'orange', nimbu: 'lemon', angoor: 'grape', anar: 'pomegranate', papita: 'papaya', amrud: 'guava', tarbooz: 'watermelon', haldi: 'turmeric', ginger: 'turmeric', dhania: 'coriander', cotton: 'cotton', sugar: 'sugarcane', beans: 'pulse' };

const ScannerPlus = {
  facing: 'environment', stream: null, currentCropKey: 'generic', lastAnalysis: null, lastSource: '', model: null, modelState: 'idle', tab: 'organic',
  $(id) { return document.getElementById(id); },
  L() { return (window.I18N && I18N.lang === 'hi') ? 'hi' : 'en'; },
  cname(k) { const c = CROP_CATALOG[k] || CROP_CATALOG.generic; return this.L() === 'hi' && HI[k] ? `${HI[k]} (${c.name})` : c.name; },
  toast(m, t) { if (window.App?.toast) App.toast(m, t || 'info'); },

  init() {
    this.enhanceUI(); this.bindEvents();
    this.renderCropInfo('generic');
    this.applySample('TOM-EB-01', true);
    document.addEventListener('langchange', () => { this.renderCropInfo(this.currentCropKey); if (this.lastAnalysis) this.render(this.lastAnalysis, this.currentCropKey, true); });
  },

  enhanceUI() {
    const zone = this.$('diseaseDropzone'); if (!zone) return;
    const t = (k, d) => (window.I18N ? I18N.t(k) : d);
    zone.className = 'upload-dropzone sp-zone';
    zone.innerHTML = `
      <input type="file" id="spFile" accept="image/*" style="display:none">
      <input type="file" id="spCam" accept="image/*" capture="environment" style="display:none">
      <div style="font-size:2rem">📸</div>
      <div style="font-weight:700;font-size:.95rem" data-i18n="sc_title">${t('sc_title', 'Scan Crop, Vegetable, Fruit or Foliage')}</div>
      <div style="font-size:.75rem;color:var(--text-muted)" data-i18n="sc_sub">${t('sc_sub', 'Instant diagnosis · Crop identification · Recovery plan')}</div>
      <div class="sp-btns">
        <button class="btn btn-primary" id="spBtnCam" type="button">📷 <span data-i18n="sc_cam">${t('sc_cam', 'Take Photo')}</span></button>
        <button class="btn btn-secondary" id="spBtnUpload" type="button">🖼️ <span data-i18n="sc_up">${t('sc_up', 'Upload from Device')}</span></button>
      </div>
      <div style="font-size:.72rem;color:var(--text-muted);margin-top:.4rem" data-i18n="sc_drag">${t('sc_drag', 'Or drag & drop any image here (JPG, PNG, WEBP)')}</div>`;
    const diagHeader = document.querySelector('#tab-disease .grid-2 > .card:last-child .card-header');
    if (diagHeader && !this.$('spCropBanner')) {
      const b = document.createElement('div'); b.id = 'spCropBanner'; b.style.cssText = 'margin:.75rem 0 1rem'; diagHeader.after(b);
    }
    const pre = this.$('diagPreventive'); // prescription tabs + recovery plan container
    if (pre && !this.$('spPlan')) { const p = document.createElement('div'); p.id = 'spPlan'; pre.parentElement.after(p); }
  },

  bindEvents() {
    const file = this.$('spFile'), cam = this.$('spCam'), zone = this.$('diseaseDropzone');
    this.$('spBtnCam').onclick = e => { e.stopPropagation(); this.takePhoto(); };
    this.$('spBtnUpload').onclick = e => { e.stopPropagation(); file.click(); };
    file.onchange = cam.onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) this.handle(f); };
    zone.onclick = e => { if (!e.target.closest('button')) file.click(); };
    ['dragover', 'dragenter'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('drag'); }));
    zone.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) this.handle(f); });
    document.querySelectorAll('.sample-leaf-card').forEach(c => c.addEventListener('click', () => this.applySample(c.dataset.code)));
    // Organic / Chemical tabs
    const bo = this.$('tabBtnOrganic'), bc = this.$('tabBtnChemical');
    if (bo && bc) { bo.onclick = () => this.showTab('organic'); bc.onclick = () => this.showTab('chemical'); }
  },

  showTab(w) {
    this.tab = w;
    const o = w === 'organic';
    this.$('paneOrganic').style.display = o ? 'block' : 'none';
    this.$('paneChemical').style.display = o ? 'none' : 'block';
    this.$('tabBtnOrganic').className = 'btn btn-sm ' + (o ? 'btn-primary' : 'btn-secondary');
    this.$('tabBtnChemical').className = 'btn btn-sm ' + (o ? 'btn-secondary' : 'btn-primary');
  },

  applySample(code, silent) {
    const s = SAMPLES[code]; if (!s) return;
    document.querySelectorAll('.sample-leaf-card').forEach(c => c.classList.toggle('active', c.dataset.code === code));
    const prev = this.$('leafPreviewImg'), ph = this.$('leafPlaceholder'), cat = CROP_CATALOG[s.crop];
    if (prev) prev.style.display = 'none';
    if (ph) { ph.style.display = 'block'; ph.innerHTML = `<span style="font-size:4rem">${cat.icon}</span><br><span style="font-size:.85rem;color:var(--text-secondary)">${this.cname(s.crop)}</span>`; }
    this.lastSource = 'sample'; this.currentCropKey = s.crop;
    this.render({ none: false, mode: 'foliage', ...s.m, blur: false }, s.crop, silent);
  },

  /* ---------- Camera ---------- */
  takePhoto() {
    const mobile = matchMedia('(pointer:coarse)').matches;
    if (mobile || !navigator.mediaDevices?.getUserMedia || !window.isSecureContext) return this.$('spCam').click();
    this.openCamera();
  },
  openCamera() {
    let m = this.$('spCamModal');
    if (!m) {
      m = document.createElement('div'); m.id = 'spCamModal'; m.className = 'modal-backdrop';
      m.innerHTML = `<div class="sp-cam"><video id="spVid" autoplay playsinline muted></video>
        <div class="sp-cam-bar"><button class="btn btn-secondary" id="spSwitch">🔄</button><button class="btn btn-primary" id="spSnap">📸</button><button class="btn btn-secondary" id="spClose">✖</button></div>
        <p class="sp-hint">Hold the leaf / fruit 20–30 cm away in bright light.</p></div>`;
      document.body.appendChild(m);
      this.$('spClose').onclick = () => this.closeCamera();
      this.$('spSwitch').onclick = () => { this.facing = this.facing === 'environment' ? 'user' : 'environment'; this.startStream(); };
      this.$('spSnap').onclick = () => this.snap();
    }
    m.style.display = 'flex'; this.startStream();
  },
  async startStream() {
    this.stopStream();
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: this.facing }, width: { ideal: 1280 } }, audio: false });
      this.$('spVid').srcObject = this.stream;
    } catch (e) { this.closeCamera(); this.toast('Camera not available — choose a photo instead.', 'error'); this.$('spCam').click(); }
  },
  stopStream() { if (this.stream) { this.stream.getTracks().forEach(t => t.stop()); this.stream = null; } },
  closeCamera() { this.stopStream(); const m = this.$('spCamModal'); if (m) m.style.display = 'none'; },
  snap() {
    const v = this.$('spVid'); if (!v.videoWidth) return;
    const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d').drawImage(v, 0, 0);
    c.toBlob(b => { this.closeCamera(); if (b) this.handle(new File([b], 'camera.jpg', { type: 'image/jpeg' })); }, 'image/jpeg', .92);
  },

  /* ---------- Crop identification ---------- */
  fromName(name) {
    name = (name || '').toLowerCase();
    for (const k of Object.keys(CROP_CATALOG)) if (k !== 'generic' && name.includes(k)) return k;
    for (const a in ALIASES) if (name.includes(a)) return ALIASES[a];
    return null;
  },
  loadScript(src) { return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); }); },
  async ensureModel() {
    if (this.model) return this.model;
    if (this.modelState === 'failed' || !navigator.onLine) return null;
    try {
      this.modelState = 'loading';
      if (!window.tf) await this.loadScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js');
      if (!window.mobilenet) await this.loadScript('https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet@2.1.1/dist/mobilenet.min.js');
      this.model = await Promise.race([mobilenet.load({ version: 2, alpha: 1.0 }), new Promise((_, r) => setTimeout(() => r('timeout'), 25000))]);
      this.modelState = 'ready'; return this.model;
    } catch (e) { this.modelState = 'failed'; return null; }
  },
  async aiGuess(img) {
    const m = await this.ensureModel(); if (!m) return null;
    try {
      const preds = await m.classify(img, 5);
      for (const p of preds) {
        const label = p.className.toLowerCase();
        for (const k in IMAGENET) if (label.includes(k) && p.probability > 0.2) return { key: IMAGENET[k], conf: p.probability };
      }
    } catch (e) {}
    return null;
  },
  colourGuess(a) {
    if (a.mode === 'produce') {
      const d = a.hue;
      if (d < 12 || d > 340) return 'tomato';
      if (d < 22) return 'carrot';
      if (d < 38) return 'orange';
      if (d < 62) return 'banana';
      if (d < 75) return 'lemon';
      return 'generic';
    }
    return null;
  },

  /* ---------- Image handling ---------- */
  async handle(file) {
    if (!/^image\//.test(file.type || 'image/jpeg')) return this.toast('Please choose an image file.', 'error');
    if (file.size > 15 * 1024 * 1024) return this.toast('Image too large (max 15 MB).', 'error');
    const url = URL.createObjectURL(file), img = new Image();
    img.onerror = () => this.toast('Could not read this image.', 'error');
    img.onload = async () => {
      const prev = this.$('leafPreviewImg'), ph = this.$('leafPlaceholder');
      if (prev) { prev.src = url; prev.style.display = 'block'; }
      if (ph) ph.style.display = 'none';
      document.querySelectorAll('.sample-leaf-card').forEach(c => c.classList.remove('active'));
      const vp = this.$('scannerViewport'); vp?.classList.add('scanning');
      this.toast('Scanning…', 'info');
      try {
        const a = this.analyse(img);
        let key = this.fromName(file.name), src = key ? 'filename' : '';
        if (!key && !a.none) { const g = await this.aiGuess(img); if (g) { key = g.key; src = `AI model ${Math.round(g.conf * 100)}%`; } }
        if (!key && !a.none) { key = this.colourGuess(a); if (key) src = 'colour estimate'; }
        if (!key) { key = this.lastSource === 'manual' ? this.currentCropKey : 'generic'; src = key === 'generic' ? '' : 'manual'; }
        this.lastSource = src; this.currentCropKey = key;
        this.render(a, key);
      } catch (e) { console.error(e); this.toast('Could not analyse this image. Try another photo.', 'error'); }
      vp?.classList.remove('scanning');
    };
    img.src = url;
  },

  rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
    if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return [h, mx ? d / mx : 0, mx];
  },

  analyse(img) {
    const S = 160, sc = Math.min(1, S / Math.max(img.width, img.height));
    const w = Math.max(8, Math.round(img.width * sc)), h = Math.max(8, Math.round(img.height * sc));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, w, h);
    const px = x.getImageData(0, 0, w, h).data, N = w * h, gray = new Float32Array(N);
    let green = 0, yellow = 0, brown = 0, dark = 0, rust = 0, bright = 0, hs = 0, hc = 0;
    for (let i = 0; i < N; i++) {
      const r = px[i * 4], g = px[i * 4 + 1], b = px[i * 4 + 2];
      gray[i] = 0.3 * r + 0.59 * g + 0.11 * b;
      const [H, s, v] = this.rgb2hsv(r, g, b);
      if (v < 0.1 || s < 0.16) continue;
      if (H >= 70 && H <= 170 && s >= 0.2) green++;
      else if (H >= 42 && H < 70 && s >= 0.3 && v >= 0.45) { yellow++; bright++; hs += H; hc++; }
      else if (H >= 8 && H < 42 && s >= 0.25 && v < 0.7) brown++;
      else if (H >= 12 && H < 40 && s >= 0.6 && v >= 0.7) { rust++; bright++; hs += H; hc++; }
      else if (v < 0.22) dark++;
      else if (H < 8 || H > 340) { bright++; hs += H > 340 ? H - 360 : H; hc++; }
    }
    let m = 0, m2 = 0, n = 0;
    for (let yy = 1; yy < h - 1; yy++) for (let xx = 1; xx < w - 1; xx++) {
      const i = yy * w + xx, l = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w]; m += l; m2 += l * l; n++;
    }
    const blur = (m2 / n - (m / n) ** 2) < 25;
    const lesion = brown + dark, leaf = green + yellow + lesion + rust, fg = leaf + bright - yellow;
    if (fg / N < 0.08) return { none: true, blur };
    const hue = hc ? (((hs / hc) % 360) + 360) % 360 : 100;
    // foliage if green dominates, otherwise it's a fruit / vegetable / grain photo
    if (green / Math.max(1, leaf + bright) >= 0.3) {
      return { none: false, mode: 'foliage', blur, hue, green: green / leaf * 100, yellow: yellow / leaf * 100, lesion: lesion / leaf * 100, rust: rust / leaf * 100 };
    }
    return { none: false, mode: 'produce', blur, hue, spoil: lesion / Math.max(1, lesion + bright + green + yellow) * 100, green: green / leaf * 100 || 0, yellow: 0, lesion: lesion / leaf * 100 };
  },

  diagnose(a) {
    if (a.mode === 'produce') {
      const sp = a.spoil, type = sp < 6 ? 'fresh' : sp < 18 ? 'minor' : 'rot';
      return { type, health: Math.max(5, Math.round(100 - sp * 3)), sev: { fresh: 'Healthy', minor: 'Mild', rot: 'Severe' }[type] };
    }
    const les = a.lesion, yel = a.yellow, rs = a.rust || 0;
    const health = Math.max(5, Math.min(100, Math.round(100 - les * 2.4 - yel * 0.7 - rs * 2)));
    if (les < 3 && yel < 10 && rs < 3) return { type: 'healthy', health, sev: 'Healthy' };
    const sev = les >= 20 || yel >= 45 || rs >= 12 ? 'Severe' : les >= 8 || yel >= 25 || rs >= 5 ? 'Moderate' : 'Mild';
    if (rs >= 4 && rs >= les / 2) return { type: 'rust', health, sev };
    if (yel >= 18 && les < 8) return { type: 'chlorosis', health, sev };
    return { type: 'spot', health, sev };
  },

  /* ---------- Rendering ---------- */
  renderCropInfo(key) {
    const banner = this.$('spCropBanner'); if (!banner) return;
    const crop = CROP_CATALOG[key] || CROP_CATALOG.generic, t = k => window.I18N ? I18N.t(k) : k;
    const opts = Object.keys(CROP_CATALOG).map(k => `<option value="${k}" ${k === key ? 'selected' : ''}>${CROP_CATALOG[k].icon} ${this.cname(k)}</option>`).join('');
    const src = this.lastSource ? `<span class="badge-ai" style="font-size:.65rem">🔎 ${this.lastSource}</span>` : '';
    banner.innerHTML = `<div style="background:var(--bg-surface);border:1px solid var(--border-color);border-radius:12px;padding:1rem">
      <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap;border-bottom:1px solid var(--border-color);padding-bottom:.7rem;margin-bottom:.7rem">
        <div style="display:flex;align-items:center;gap:.75rem"><div style="font-size:2.3rem;padding:.4rem;background:rgba(16,185,129,.1);border-radius:10px">${crop.icon}</div>
          <div><h3 style="margin:0;font-size:1.2rem;font-weight:800">${this.cname(key)}</h3>
            <div style="display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.2rem"><span class="badge-ai" style="background:${crop.badgeColor}22;color:${crop.badgeColor};border:1px solid ${crop.badgeColor}55;font-size:.7rem">${crop.categoryBadge}</span>${src}</div>
            <div style="font-size:.74rem;color:var(--text-muted);margin-top:.2rem"><i>${crop.botanical}</i> · ${crop.family}</div></div></div>
        <div style="text-align:right"><label style="font-size:.72rem;color:var(--text-muted);display:block;margin-bottom:.2rem">${t('sc_change')}</label>
          <select id="spCropSelect" class="form-control" style="font-size:.8rem;padding:.25rem .5rem;height:auto;max-width:220px">${opts}</select></div></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:.6rem;font-size:.78rem">
        ${[['🌱', 'sc_nature', crop.nature, 'var(--primary)'], ['🍎', 'sc_nutri', crop.nutrition, '#f59e0b'], ['⛅', 'sc_climate', crop.climate, '#3b82f6'], ['💧', 'sc_care', crop.care, '#10b981']].map(([i, k, v, c]) =>
      `<div style="background:var(--bg-card);padding:.6rem .75rem;border-radius:8px;border:1px solid var(--border-color)"><div style="color:${c};font-weight:700;margin-bottom:.15rem">${i} ${t(k)}</div><div style="color:var(--text-secondary);line-height:1.35">${v}</div></div>`).join('')}
      </div></div>`;
    this.$('spCropSelect').onchange = e => {
      this.currentCropKey = e.target.value; this.lastSource = 'manual';
      this.render(this.lastAnalysis || { none: false, mode: 'foliage', green: 95, yellow: 3, lesion: 2, blur: false }, this.currentCropKey, true);
    };
  },

  render(a, key, silent) {
    this.lastAnalysis = a; this.currentCropKey = key;
    this.renderCropInfo(key);
    const L = this.L(), T = TX[L], crop = CROP_CATALOG[key] || CROP_CATALOG.generic;
    const set = (id, t) => { const el = this.$(id); if (el) el.textContent = t; };
    const html = (id, t) => { const el = this.$(id); if (el) el.innerHTML = t; };
    const plan = this.$('spPlan');
    if (a.none) {
      const n = T.none;
      set('diagDiseaseName', n.n); set('diagCropName', this.cname(key)); set('diagPathogen', n.p); set('diagSymptoms', n.s); set('diagConfidence', '—');
      html('diagOrganic', ''); html('diagChemical', ''); set('diagPreventive', ''); set('diagSeverity', '—');
      if (plan) plan.innerHTML = ''; return;
    }
    const d = this.diagnose(a), g = T[d.type];
    const col = { Healthy: '#10b981', Mild: '#10b981', Moderate: '#f59e0b', Severe: '#ef4444' }[d.sev];
    const sevLbl = L === 'hi' ? { Healthy: 'स्वस्थ', Mild: 'हल्का', Moderate: 'मध्यम', Severe: 'गंभीर' }[d.sev] : d.sev;
    let name = g.n, path = g.p, org = g.o, chem = g.c;
    const sp = DIS[key];
    if (sp && (d.type === 'spot' || d.type === 'rust')) {
      name = `${crop.name} – ${sp[0]}${L === 'hi' ? ' (' + sp[1] + ')' : ''}`; path = sp[2]; org = `${g.o}\n${sp[3]}`; chem = `${g.c}\n${sp[4]}`;
    } else if (key !== 'generic') name = `${this.cname(key)} – ${g.n}`;
    set('diagDiseaseName', name); set('diagCropName', `${crop.icon} ${this.cname(key)}`); set('diagPathogen', path); set('diagSymptoms', g.s);
    html('diagOrganic', `<p style="white-space:pre-line">${org}</p>`); html('diagChemical', `<p style="white-space:pre-line">${chem}</p>`);
    set('diagPreventive', g.v); set('diagConfidence', `${L === 'hi' ? 'स्वास्थ्य' : 'Health'}: ${d.health}%`);
    const sv = this.$('diagSeverity'); if (sv) { sv.textContent = sevLbl; sv.style.color = col; sv.style.background = col + '22'; }
    this.showTab(this.tab);
    const good = d.sev === 'Healthy', warn = a.blur ? `<p class="sp-warn">⚠️ ${L === 'hi' ? 'फोटो थोड़ी धुंधली है, स्थिर हाथ और दिन की रोशनी में दोबारा लें।' : 'Photo is a bit blurry — retake in daylight with a steady hand.'}</p>` : '';
    const stats = a.mode === 'produce' ? `${L === 'hi' ? 'खराबी' : 'Spoilage'} ${a.spoil.toFixed(0)}%` : `${L === 'hi' ? 'हरा' : 'Green'} ${a.green.toFixed(0)}% · ${L === 'hi' ? 'पीलापन' : 'Yellow'} ${a.yellow.toFixed(0)}% · ${L === 'hi' ? 'धब्बे' : 'Lesions'} ${a.lesion.toFixed(0)}%`;
    const title = good ? (L === 'hi' ? '✅ सर्वोत्तम खेती-पद्धति' : '✅ Keep it healthy') : (L === 'hi' ? '🩺 फसल को ठीक करने की योजना (कदम-दर-कदम)' : '🩺 How to recover this crop (step by step)');
    const eta = good ? '' : `<p class="sp-note" style="margin:.5rem 0 0">⏱️ ${L === 'hi' ? 'सही इलाज से सुधार आमतौर पर 7–21 दिन में दिखता है।' : 'With correct treatment, improvement is usually visible within 7–21 days.'}</p>`;
    if (plan) plan.innerHTML = `
      <div class="sp-health" style="margin-top:.75rem"><div class="sp-bar"><i style="width:${d.health}%;background:${col}"></i></div><small>${L === 'hi' ? 'स्वास्थ्य स्कोर' : 'Health score'}: <b>${d.health}%</b> · ${stats}</small></div>${warn}
      <div class="sp-plan ${good ? 'good' : 'bad'}"><h4>${title}</h4><ol>${g.st.map(s => `<li><b>${s[0]}:</b> ${s[1]}</li>`).join('')}</ol>${eta}</div>
      <p class="sp-note">ℹ️ ${L === 'hi' ? 'यह फोटो-आधारित अनुमान है। पक्की जांच के लिए नज़दीकी कृषि विज्ञान केंद्र (KVK) से संपर्क करें। दवा का प्रयोग लेबल के अनुसार करें।' : 'This is an image-based estimate. For a confirmed diagnosis contact your local Krishi Vigyan Kendra (KVK). Always follow the product label.'}</p>`;
    if (!silent) this.toast(good ? `${crop.icon} ${this.cname(key)} — ${g.n}` : `${name} (${sevLbl})`, good ? 'success' : 'info');
  }
};

window.ScannerPlus = ScannerPlus;
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => ScannerPlus.init()); else ScannerPlus.init();
